+++
title = "Welcome to the Test Website"
date = 2021-04-23
draft = false
coucou = false
array = [1,2,3,4,5,6]
template = "cmTemp.html"
+++

# Common Mark

Common Mark is the basic markup format adopted for the project.

You should check that your implementation supports:

- _italics_ (using underscores) and *italics* (using stars),

- **bold** (using double stars),

- bulleted lists,
d
- etc.

The CommonMark spec can be found [online](http://spec.commonmark.org).
